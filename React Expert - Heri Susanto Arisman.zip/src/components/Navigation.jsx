import React from 'react';
import { MdLeaderboard, MdLogin, MdLogout } from 'react-icons/md';
import { GoCommentDiscussion } from 'react-icons/go';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/auth/authSlice';

const Navigation = () => {
  const { user } = useSelector((state) => state.auth);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  return (
    <>
      <div className='sticky bottom-0 z-10 w-full py-2 flex justify-evenly items-center border border-gray-300 bg-white'>
        <div
          className='flex flex-col items-center'
          onClick={() => navigate('/')}
        >
          <GoCommentDiscussion />
          <p>Threads</p>
        </div>
        <div
          className='flex flex-col items-center'
          onClick={() => navigate('/leaderboards')}
        >
          <MdLeaderboard />
          <p>Leaderboards</p>
        </div>
        {user ? (
          <div
            className='flex flex-col items-center'
            onClick={() => dispatch(logout()).then(() => navigate('/login'))}
          >
            <MdLogout />
            <p>Logout</p>
          </div>
        ) : (
          <div
            className='flex flex-col items-center'
            onClick={() => navigate('/login')}
          >
            <MdLogin />
            <p>Login</p>
          </div>
        )}
      </div>
    </>
  );
};

export default Navigation;
